# holbertonschool-higher_level_programming

## Python and JavaScript projects done for school
