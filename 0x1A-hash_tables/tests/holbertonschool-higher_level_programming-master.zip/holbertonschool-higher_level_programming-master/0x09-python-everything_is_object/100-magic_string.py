#!/usr/bin/python3
def magic_string(Holby=[]):
    Holby += ["Holberton"]
    return (", ".join(Holby))
