#!/usr/bin/python3
"""Locked Class module"""


class LockedClass:
    """class with only one attribute"""
    __slots__ = ("first_name",)
