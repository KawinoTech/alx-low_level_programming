#!/bin/bash
# A header variable X-HolbertonSchool-User-Id must be sent with the value 98
curl -s -H 'X-HolbertonSchool-User-Id: 98' "$1"
