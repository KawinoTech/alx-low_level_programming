#!/bin/bash
# send delete request
curl -s -X  DELETE "$1"
