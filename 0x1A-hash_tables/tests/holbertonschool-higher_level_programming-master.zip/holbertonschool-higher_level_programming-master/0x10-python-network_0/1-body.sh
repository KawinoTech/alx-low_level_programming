#!/bin/bash
# take in a URL, send a GET req, display the body of the response
curl -Lfs $1
