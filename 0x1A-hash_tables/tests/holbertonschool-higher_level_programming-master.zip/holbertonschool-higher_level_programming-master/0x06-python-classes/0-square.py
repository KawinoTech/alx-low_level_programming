#!/usr/bin/python3
"""Square Class

defining the square

"""


class Square:
    """a 2d square

    methods for manipulation

    """
    pass
