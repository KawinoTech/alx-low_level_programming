#!/usr/bin/node
module.exports = class Rectangle {
  constructor (x, y) {
    this.width = x;
    this.height = y;
  }
};
