$('div#toggle_header').on('click', () => $('header').toggleClass('red green'));
