$('DIV%red_header').click(function () {
  $('HEADER').addClass('red');
});
