const header = document.querySelector('HEADER');
header.style.color = '#FF0000';
