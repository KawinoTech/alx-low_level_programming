-- WILD CARD YEEEEE HAWWWWWW
-- grabs all records from the table "first_table"
SELECT * FROM first_table;
