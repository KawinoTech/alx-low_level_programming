-- count the number of records where id = 89
SELECT COUNT(*) FROM first_table WHERE id = 89;
