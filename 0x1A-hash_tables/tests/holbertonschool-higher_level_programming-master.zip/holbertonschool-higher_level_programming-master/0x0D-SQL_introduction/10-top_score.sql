-- list students from the "second_table" by score in descending order
SELECT score, name FROM second_table ORDER BY score DESC;
