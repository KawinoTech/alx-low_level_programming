-- prints the full description of the table first_table from the database
SHOW CREATE TABLE first_table;
