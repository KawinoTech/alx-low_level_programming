-- shows all databases
SHOW DATABASES;
