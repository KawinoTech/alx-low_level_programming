-- create database hbtn_0c_0 if not already existing
CREATE DATABASE IF NOT EXISTS hbtn_0c_0;
