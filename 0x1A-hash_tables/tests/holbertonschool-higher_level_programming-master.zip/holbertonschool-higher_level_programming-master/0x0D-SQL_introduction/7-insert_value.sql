-- insett these values into the tableid = 89, name = Holberton School
INSERT INTO `first_table` (`id`, `name`) VALUES ("89", "Holberton School");
