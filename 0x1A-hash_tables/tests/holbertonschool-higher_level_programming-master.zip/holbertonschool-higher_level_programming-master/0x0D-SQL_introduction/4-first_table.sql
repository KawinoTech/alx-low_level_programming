-- creates a new "first_table" in our databse
CREATE TABLE IF NOT EXISTS first_table (id INT, name VARCHAR(256));
