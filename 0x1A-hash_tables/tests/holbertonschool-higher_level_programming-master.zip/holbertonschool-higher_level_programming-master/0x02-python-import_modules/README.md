Third higher level programming project at Holberton, learning python imports
