#!/usr/bin/python3
getattr(__builtins__, b'\x70\x72\x69\x6e\x74'.decode())('#pythoniscool')
