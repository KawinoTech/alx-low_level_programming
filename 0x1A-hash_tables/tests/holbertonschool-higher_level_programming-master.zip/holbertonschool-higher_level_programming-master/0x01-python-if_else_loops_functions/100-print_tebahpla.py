#!/usr/bin/python3
for z in range(-122, -96):

