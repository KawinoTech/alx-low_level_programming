#!/usr/bin/python3
for z in range(99):
    print('{:d} = {}'.format(z, hex(z)))
