#!/usr/bin/python3
for z in range(97, 123):
    print("{:c}".format(z), end="")
