Second Higher level programming project at Holberton
