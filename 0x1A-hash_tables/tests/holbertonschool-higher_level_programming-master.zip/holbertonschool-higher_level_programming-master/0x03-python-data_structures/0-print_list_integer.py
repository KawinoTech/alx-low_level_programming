#!/usr/bin/python3
def print_list_integer(my_list=[]):
    for z in my_list:
        print("{:d}".format(z))
