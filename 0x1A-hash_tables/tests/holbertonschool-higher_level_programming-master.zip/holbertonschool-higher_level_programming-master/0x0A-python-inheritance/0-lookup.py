#!/usr/bin/python3


def lookup(obj):
    return dir(obj)
