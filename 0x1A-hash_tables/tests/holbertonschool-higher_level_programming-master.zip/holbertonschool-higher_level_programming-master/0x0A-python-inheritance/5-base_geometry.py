#!/usr/bin/python3


class BaseGeometry:
    pass
