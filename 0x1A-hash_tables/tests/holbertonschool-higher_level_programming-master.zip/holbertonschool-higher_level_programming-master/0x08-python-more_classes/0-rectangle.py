#!/usr/bin/python3
"""defines a Rectangle"""


class Rectangle:
    """Rectangle class"""
    pass
