#!/usr/bin/python3


def class_to_json(obj):
    return vars(obj)
