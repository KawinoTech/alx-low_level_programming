#!/usr/bin/python3


import json


def from_json_string(my_str):
    return json.loads(my_str)
