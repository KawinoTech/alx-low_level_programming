#!/usr/bin/node

const Lang = ['C is fun', 'Python is cool', 'Javascript is amazing'];
for (let index = 0; index < Lang.length; index++) {
  console.log(Lang[index]);
}
