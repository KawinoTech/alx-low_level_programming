#!/usr/bin/node

const process = require('process');
console.log(process.argv[2] + ' is ' + process.argv[3]);
