#!/usr/bin/node

console.log('C is fun');
console.log('Python is cool');
console.log('Javascript is amazing');
