#!/usr/bin/node

const myVar = 'Javascript is amazing';
console.log(myVar);
