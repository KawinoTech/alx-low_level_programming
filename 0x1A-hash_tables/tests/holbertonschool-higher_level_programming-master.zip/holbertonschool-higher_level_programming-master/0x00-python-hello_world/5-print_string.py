#!/usr/bin/python3
str = "Holberton School"
print("{}{}{}\n{}".format(str, str, str, str[:9]))
