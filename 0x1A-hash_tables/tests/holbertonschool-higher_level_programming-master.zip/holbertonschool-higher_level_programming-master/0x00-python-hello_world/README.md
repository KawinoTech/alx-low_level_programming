Our first Higher level programming project at Holberton
