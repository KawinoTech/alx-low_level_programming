#!/usr/bin/python3
mutiply_list_map = __import__('11-mutiply_list_map').mutiply_list_map

my_list = [1, 2, 3, 4, 6]
new_list = mutiply_list_map(my_list, 4)
print(new_list)
print(my_list)
