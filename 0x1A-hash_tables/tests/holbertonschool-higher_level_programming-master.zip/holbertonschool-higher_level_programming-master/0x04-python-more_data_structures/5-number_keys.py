#!/usr/bin/python3
def number_keys(a_dictionary):
    return len(a_dictionary)
